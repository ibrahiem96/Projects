/*
 * Authors: Ibrahiem Mohammad
 *     Jacky Duong
 * 
 * Date: 3/1/16
 * 
 * UIC CS 342
 * 
 * Description: Different test cases for the game minesweeper.
 * 
 * 
 */

import static org.junit.Assert.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.*;
import org.junit.Test;
import static java.lang.Thread.sleep;
import java.io.IOException;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

public class MineTest{
  
   //@Test
  public void testRandomLabel() throws IOException
  {
    MineSweeper frame;
    JLabel inputTest;
    
    String expResult;
    
    frame = new MineSweeper();
    frame.setVisible(true);
    
   
    
    inputTest = (JLabel)TestUtils.getChildNamed(frame,"timeText");
    assertNotNull("Can't find component",inputTest);
    expResult = "000";
    assertEquals(expResult,inputTest.getText());
  }
  
   //@Test
  public void testClicked() throws IOException, InterruptedException
  {
    Robot robot;
   try {
            robot = new Robot();
        } catch (AWTException e) {
            throw new RuntimeException(e);
        }
    MineSweeper frame;
    MineSweeper.MyJButton inputTest;
    MineSweeper.MyJButton resetButton;
    JMenu menu1;
    
    boolean expResult;
 
    frame = new MineSweeper();
    frame.setVisible(true);
        
    robot.mouseMove(60, 130);
    robot.delay(300);
    robot.mousePress(InputEvent.BUTTON1_MASK);
    robot.delay(200);
    robot.mouseRelease(InputEvent.BUTTON1_MASK);
    
    menu1 = (JMenu)TestUtils.getChildNamed(frame,"menu1");
    inputTest = (MineSweeper.MyJButton)TestUtils.getChildNamed(frame,"Button00");
    resetButton = (MineSweeper.MyJButton)TestUtils.getChildNamed(frame,"resetB");
    sleep(1000);
    expResult = false;
    assertEquals(expResult,inputTest.isEnabled());
    
    
  }
   //@Test
  public void mineDecrease() throws IOException, InterruptedException
  {
    Robot robot;
   try {
            robot = new Robot();
        } catch (AWTException e) {
            throw new RuntimeException(e);
        }
    MineSweeper frame;
    JLabel inputTest;
    String expResult;
    
    frame = new MineSweeper();
    frame.setVisible(true);
    
    
    robot.mouseMove(60, 130);
    robot.delay(300);
    robot.mousePress(InputEvent.BUTTON3_MASK);
    robot.delay(200);
    robot.mouseRelease(InputEvent.BUTTON3_MASK);
    
    inputTest = (JLabel)TestUtils.getChildNamed(frame,"minesLeft");
    sleep(500);
    expResult = "9";
    assertEquals(expResult,inputTest.getText());
  }
  
   //@Test
  public void resetSmileTest() throws IOException, InterruptedException
  {
    Robot robot;
   try {
            robot = new Robot();
        } catch (AWTException e) {
            throw new RuntimeException(e);
        }
    MineSweeper frame;
    MineSweeper.MyJButton inputTest;
    MineSweeper.MyJButton resetButton;
    boolean expResult;
    
    frame = new MineSweeper();
    frame.setVisible(true);
    
    
    robot.mouseMove(60, 130);
    robot.delay(300);
    robot.mousePress(InputEvent.BUTTON1_MASK);
    robot.delay(200);
    robot.mouseRelease(InputEvent.BUTTON1_MASK);
    
   
    inputTest = (MineSweeper.MyJButton)TestUtils.getChildNamed(frame,"Button11");
    resetButton = (MineSweeper.MyJButton)TestUtils.getChildNamed(frame,"resetB");
    robot.mouseMove(300, 75);
    robot.delay(300);
    robot.mousePress(InputEvent.BUTTON1_MASK);
    robot.delay(200);
    robot.mouseRelease(InputEvent.BUTTON1_MASK);
    
    sleep(500);
    expResult = true;
    for(int i = 0; i < 10; i++)
    {
      for(int j = 0; j< 10; j++)
      {
        inputTest = (MineSweeper.MyJButton)TestUtils.getChildNamed(frame,"Button"+i+j);
        assertEquals(expResult,inputTest.isEnabled());
      }
    }
    
  }
   
  // @Test
  public void testAboutMenuHelp() throws IOException, InterruptedException
  {
    Robot robot;
   try {
            robot = new Robot();
        } catch (AWTException e) {
            throw new RuntimeException(e);
        }
    MineSweeper frame;
    JMenu menu1;
    JMenuItem aboutButton;
    boolean expResult;
    
    frame = new MineSweeper();
    frame.setVisible(true);
    
    menu1 = (JMenu)TestUtils.getChildNamed(frame,"menu2");
    aboutButton = (JMenuItem)TestUtils.getChildNamed(frame,"aboutButton");
    menu1.doClick();
    sleep(2000);
    robot.keyPress(KeyEvent.VK_A);
    robot.keyRelease(KeyEvent.VK_A);
    robot.delay(1000);
    sleep(1000);
    robot.keyPress(KeyEvent.VK_ENTER);
    robot.keyRelease(KeyEvent.VK_ENTER);
    
  }
   //@Test
  public void testHelpKeyboardMenuHelp() throws IOException, InterruptedException
  {
    Robot robot;
   try {
            robot = new Robot();
        } catch (AWTException e) {
            throw new RuntimeException(e);
        }
    MineSweeper frame;
    
    JMenu menu1;
    JMenuItem helpButton;
    
    boolean expResult;
    
    frame = new MineSweeper();
    frame.setVisible(true);
    
    menu1 = (JMenu)TestUtils.getChildNamed(frame,"menu2");
    helpButton = (JMenuItem)TestUtils.getChildNamed(frame,"helpButton");
    sleep(2000);
    menu1.doClick();
    sleep(1000);
    robot.keyPress(KeyEvent.VK_H);
    robot.keyRelease(KeyEvent.VK_H);
    robot.delay(1000);
    robot.keyPress(KeyEvent.VK_ENTER);
    robot.keyRelease(KeyEvent.VK_ENTER);
  }
  
   //@Test
  public void mineandQuestionTest() throws IOException, InterruptedException
  {
    Robot robot;
   try {
            robot = new Robot();
        } catch (AWTException e) {
            throw new RuntimeException(e);
        }
    MineSweeper frame;
    MineSweeper.MyJButton inputTest;
    boolean expResult;
    
    frame = new MineSweeper();
    frame.setVisible(true);
    
    
    robot.mouseMove(60, 130);
    robot.delay(300);
    robot.mousePress(InputEvent.BUTTON3_MASK);
    robot.delay(200);
    robot.mouseRelease(InputEvent.BUTTON3_MASK);
    inputTest = (MineSweeper.MyJButton)TestUtils.getChildNamed(frame,"Button11");
    sleep(500);
    expResult = true;
    String expString = "M";
    robot.delay(300);
    robot.mousePress(InputEvent.BUTTON1_MASK);
    robot.delay(200);
    robot.mouseRelease(InputEvent.BUTTON1_MASK);
    //sees if nothing happens when user left clicks on a "M"
    sleep(1000);
    assertEquals(expResult,inputTest.isEnabled());
    
    robot.delay(300);
    robot.mousePress(InputEvent.BUTTON3_MASK);
    robot.delay(200);
    robot.mouseRelease(InputEvent.BUTTON3_MASK);
    
    expString = "?";
    robot.delay(300);
    robot.mousePress(InputEvent.BUTTON1_MASK);
    robot.delay(200);
    robot.mouseRelease(InputEvent.BUTTON1_MASK);
    //sees if nothing happens when user left clicks on a "?"
    assertEquals(expResult,inputTest.isEnabled());
  }
   //@Test
  public void timerTest() throws IOException, InterruptedException
  {
    Robot robot;
   try {
            robot = new Robot();
        } catch (AWTException e) {
            throw new RuntimeException(e);
        }
    MineSweeper frame;
    JLabel textTime;
    
    String expResult;
    
    frame = new MineSweeper();
    frame.setVisible(true);
    
    textTime = (JLabel)TestUtils.getChildNamed(frame,"timeText");
    expResult = "005";
    robot.mouseMove(60, 130);
    robot.delay(300);
    robot.mousePress(InputEvent.BUTTON3_MASK);
    robot.mouseRelease(InputEvent.BUTTON3_MASK);
    
   
    sleep(5100);
    
    assertEquals(expResult,textTime.getText());
  }
    @SuppressWarnings("deprecation")
public void mineSetupTest() throws IOException, InterruptedException{
   
   
   MineSweeper frame = new MineSweeper();
   
   assertEquals(false,frame.bounds().isEmpty());
   
  }
  
//  //@Test
public void reset_Test_1() throws IOException, InterruptedException{
   
   
   MineSweeper frame = new MineSweeper();
   
   frame.resetBoard();
   
     for(int i = 0; i < 10; i++)
     {
       for(int j = 0; j <10; j++)
       {
         assertEquals(true, frame.buttons[i][j].isEnabled());
       }
     }   
  }

 //@Test
public void reset_Test_2() throws IOException, InterruptedException{
   
   
   MineSweeper frame = new MineSweeper();
   
   frame.resetBoard();
   
     for(int i = 0; i < 10; i++)
     {
       for(int j = 0; j <10; j++)
       {
         assertEquals("", frame.buttons[i][j].getText());
       }
     }
      
}

 //@Test
public void reset_Test_3() throws IOException, InterruptedException{
   
   
   MineSweeper frame = new MineSweeper();
   int ctr = 0;
   frame.showMines();
   
     for(int i = 0; i < 10; i++)
     {
       for(int j = 0; j <10; j++)
       {
         if ("*" == frame.buttons[i][j].getText()){ctr++;}
       }
     }
      
     assertEquals(10, ctr);
}

 //@Test
public void window_2() throws IOException, InterruptedException{
 
 
  MineSweeper frame = new MineSweeper();
  
  assertEquals(true,frame.isResizable());
 
}


 //@Test
public void window_3() throws IOException, InterruptedException{
 
 
  MineSweeper frame = new MineSweeper();
  
  assertEquals(true,frame.isValid());
  
}
 //@Test
public void addScoreTest() throws IOException, InterruptedException
{
  MineSweeper frame = new MineSweeper();
  String expResult = "JackyDuong095";
  String firstLine;
   File file = new File("scores.txt");
        if(!file.exists())
          file.createNewFile();
  try{
        PrintWriter pw = new PrintWriter(new FileWriter("scores.txt"));
        pw.print("");
        pw.close();
      }catch (IOException ee) {
        ee.printStackTrace();
      }
  frame.writeFile(expResult);
  BufferedReader br = new BufferedReader(new FileReader(file));
  firstLine =  br.readLine();
  assertEquals(firstLine,expResult);
}

//@Test
public void resetScoreTest() throws IOException, InterruptedException
{
  Robot robot;
   try {
            robot = new Robot();
        } catch (AWTException e) {
            throw new RuntimeException(e);
        }
    MineSweeper frame = new MineSweeper();
    JMenu menu1;
    JMenuItem resetScoreButton;
    JMenuItem topButton;
    String expResult = "JackyDuong935";
    String firstLine;
    
    File file = new File("scores.txt");
        if(!file.exists())
          file.createNewFile();
    //robot.mouseMove(60, 130);
    //String empty = "nothing111";
    
    menu1 = (JMenu)TestUtils.getChildNamed(frame,"menu1");
    resetScoreButton = (JMenuItem)TestUtils.getChildNamed(frame,"resetScoreButton");
    topButton = (JMenuItem)TestUtils.getChildNamed(frame,"topButton");
    frame.writeFile(expResult);
    sleep(1000);
    menu1.doClick();
    sleep(1000);
    
    robot.keyPress(KeyEvent.VK_T);
    robot.keyRelease(KeyEvent.VK_T);
    sleep(1000);
    robot.delay(1000);
    robot.keyPress(KeyEvent.VK_ENTER);
    robot.keyRelease(KeyEvent.VK_ENTER);
    
    sleep(1000);
    menu1.doClick();
    sleep(1000);
    resetScoreButton.doClick();
    
    BufferedReader br = new BufferedReader(new FileReader(file));
    firstLine =  br.readLine();
    expResult = null;
    assertEquals(expResult,firstLine);
}
//@Test
  public void testMenuExit() throws IOException, InterruptedException
  {
    MineSweeper frame;
    JMenu menu1;
    JMenuItem exitButton;
    
    boolean expResult;
    
    frame = new MineSweeper();
    frame.setVisible(true);
    
    menu1 = (JMenu)TestUtils.getChildNamed(frame,"menu1");
    exitButton = (JMenuItem)TestUtils.getChildNamed(frame,"exitButton");
    
    menu1.doClick();
    
    sleep(2000);
    exitButton.doClick();
    
    
    
  }
  //@Test
  public void testResetMenu() throws IOException, InterruptedException
  {
    Robot robot;
   try {
            robot = new Robot();
        } catch (AWTException e) {
            throw new RuntimeException(e);
        }
    MineSweeper frame;
    JMenu menu1;
    JMenuItem aboutButton;
    boolean expResult;
    
    frame = new MineSweeper();
    frame.setVisible(true);
    
    robot.mouseMove(60, 130);
    robot.delay(300);
    robot.mousePress(InputEvent.BUTTON1_MASK);
    robot.delay(200);
    robot.mouseRelease(InputEvent.BUTTON1_MASK);
    
    menu1 = (JMenu)TestUtils.getChildNamed(frame,"menu1");
    aboutButton = (JMenuItem)TestUtils.getChildNamed(frame,"resetMenu");
    menu1.doClick();
    sleep(2000);
    robot.keyPress(KeyEvent.VK_R);
    robot.keyRelease(KeyEvent.VK_R);
    robot.delay(1000);
    sleep(1000);
    robot.keyPress(KeyEvent.VK_ENTER);
    robot.keyRelease(KeyEvent.VK_ENTER);
    
    for(int i = 0; i < 10; i++)
     {
       for(int j = 0; j <10; j++)
       {
         assertEquals(true, frame.buttons[i][j].isEnabled());
       }
     }
    
  }
  
}

