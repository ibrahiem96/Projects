/*
 * Authors: Ibrahiem Mohammad
 *     Jacky Duong
 * 
 * Date: 3/1/16
 * 
 * UIC CS 342
 * 
 * Description: JUnit runner for MineTest
 * 
 * 
 * 
 */

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class JunitRunner {

 public static void main(String[] args) {

  Result result = JUnitCore.runClasses( MineTest.class );
  for (Failure fail : result.getFailures()) {
   System.out.println(fail.toString());
  }
  if (result.wasSuccessful()) {
   System.out.println("All tests finished successfully...");
  }
 }
}
